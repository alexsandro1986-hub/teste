package alex;
public class Calculadora {
     
    public Integer soma (Integer v1, Integer v2){
        return v1 + v2 ;
        
    }

    public Integer subtracao (Integer v1, Integer v2){
        return v1 - v2 ;
        
    }

    public Integer multiplicacao (Integer v1, Integer v2){
        return v1 * v2 ;
        
    }

    public Integer divisao (Integer v1, Integer v2){
        return v1 / v2 ;
        
    }


}

